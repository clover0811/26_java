package com.market.bookitem;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class BookInIt {
    private static final String BOOK_FILE = "book.txt";

    public static Book[] init() {
        List<Book> books = new ArrayList<>();

        try (InputStream input = BookInIt.class.getResourceAsStream(BOOK_FILE)) {
            if (input != null) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (line.trim().isEmpty()) {
                            continue;
                        }
                        String[] data = line.split("\\|");
                        if (data.length >= 7) {
                            Book book = new Book(data[0], data[1], Integer.parseInt(data[2]));
                            book.setAuthor(data[3]);
                            book.setDescription(data[4]);
                            book.setCategory(data[5]);
                            book.setReleaseDate(data[6]);
                            books.add(book);
                        }
                    }
                }
            }
        } catch (IOException | NumberFormatException e) {
            books.clear();
        }

        if (books.isEmpty()) {
            books.add(createBook("ISBN1234", "쉽게 배우는 JSP 웹 프로그래밍", 27000, "송미영", "단계별로 쇼핑몰을 구현하며 배우는 JSP 웹 프로그래밍", "IT전문서", "2018/10/08"));
            books.add(createBook("ISBN1235", "안드로이드 프로그래밍", 33000, "우재남", "실습 단계별 명쾌한 멘토링", "IT전문서", "2022/01/22"));
            books.add(createBook("ISBN1236", "스크래치", 22000, "고광일", "컴퓨팅 사고력을 키우는 블록 코딩", "컴퓨터입문", "2019/06/10"));
        }

        return books.toArray(new Book[0]);
    }

    private static Book createBook(String bookId, String name, int unitPrice, String author, String description, String category, String releaseDate) {
        Book book = new Book(bookId, name, unitPrice);
        book.setAuthor(author);
        book.setDescription(description);
        book.setCategory(category);
        book.setReleaseDate(releaseDate);
        return book;
    }
}
