package com.market.cart;

import com.market.bookitem.Book;
import com.market.exception.CartException;

public class Cart implements CartInterface {
    static final int NUM_BOOK = 3;
    public CartItem[] mCartItem = new CartItem[NUM_BOOK];
    public int mCartCount = 0;

    public Cart() {
    }

    @Override
    public void printBookList(Book[] bookList) {
        for (Book book : bookList) {
            System.out.print(book.getBookId() + " | ");
            System.out.print(book.getName() + " | ");
            System.out.print(book.getUnitPrice() + " | ");
            System.out.print(book.getAuthor() + " | ");
            System.out.print(book.getDescription() + " | ");
            System.out.print(book.getCategory() + " | ");
            System.out.println(book.getReleaseDate());
        }
    }

    @Override
    public boolean isCartInBook(String bookId) {
        boolean flag = false;
        for (int i = 0; i < mCartCount; i++) {
            if (bookId.equals(mCartItem[i].getBookId())) {
                mCartItem[i].setQuantity(mCartItem[i].getQuantity() + 1);
                flag = true;
                break;
            }
        }
        return flag;
    }

    @Override
    public void insertBook(Book book) {
        if (mCartCount >= mCartItem.length) {
            System.out.println("장바구니가 가득 찼습니다.");
            return;
        }
        mCartItem[mCartCount++] = new CartItem(book);
    }

    @Override
    public void removeCart(int numId) {
        CartItem[] cartItem = new CartItem[NUM_BOOK];
        int num = 0;
        for (int i = 0; i < mCartCount; i++) {
            if (i != numId) {
                cartItem[num++] = mCartItem[i];
            }
        }
        mCartCount = num;
        mCartItem = cartItem;
    }

    @Override
    public void deleteBook() {
        mCartItem = new CartItem[NUM_BOOK];
        mCartCount = 0;
    }

    public void printCart() throws CartException {
        if (mCartCount == 0) {
            throw new CartException("장바구니에 항목이 없습니다.");
        }
        System.out.println("장바구니 상품 목록 :");
        System.out.println("------------------------------------------------");
        System.out.println("도서ID \t\t 수량 \t 합계");
        for (int i = 0; i < mCartCount; i++) {
            System.out.print(mCartItem[i].getBookId() + " \t ");
            System.out.print(mCartItem[i].getQuantity() + " \t ");
            System.out.println(mCartItem[i].getTotalPrice());
        }
        System.out.println("------------------------------------------------");
    }

    public CartItem[] getmCartItem() {
        return mCartItem;
    }

    public void setmCartItem(CartItem[] mCartItem) {
        this.mCartItem = mCartItem;
    }

    public int getmCartCount() {
        return mCartCount;
    }

    public void setmCartCount(int mCartCount) {
        this.mCartCount = mCartCount;
    }
    
    public int getTotalPrice() {
        int sum = 0;
        for (int i = 0; i < mCartCount; i++) {
            sum += mCartItem[i].getTotalPrice();
        }
        return sum;
    }
}
