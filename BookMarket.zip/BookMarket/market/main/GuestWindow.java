package com.market.main;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.market.member.UserInIt;

public class GuestWindow extends JFrame {
    private JTextField nameField;
    private JTextField phoneField;

    public GuestWindow() {
        setTitle("고객 정보 입력");
        setSize(400, 260);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel("고객 정보를 입력하세요", SwingConstants.CENTER);
        add(title, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        inputPanel.add(new JLabel("이름"));
        nameField = new JTextField();
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("연락처"));
        phoneField = new JTextField();
        inputPanel.add(phoneField);
        add(inputPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton enterButton = new JButton("입력 완료");
        JButton cancelButton = new JButton("취소");
        buttonPanel.add(enterButton);
        buttonPanel.add(cancelButton);
        add(buttonPanel, BorderLayout.SOUTH);

        enterButton.addActionListener(e -> enterGuestInfo());
        cancelButton.addActionListener(e -> System.exit(0));
    }

    private void enterGuestInfo() {
        String name = nameField.getText().trim();
        String phoneText = phoneField.getText().trim();

        if (name.isEmpty() || phoneText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "고객 정보를 입력하세요.");
            return;
        }

        try {
            int phone = Integer.parseInt(phoneText);
            UserInIt.init(name, phone);
            new MainWindow().setVisible(true);
            dispose();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "연락처는 숫자로 입력하세요.");
        }
    }
}
