package com.market.main;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.JLabel;

import com.market.bookitem.Book;
import com.market.bookitem.BookInIt;
import com.market.cart.Cart;
import com.market.member.UserInIt;
import com.market.page.AdminLoginDialog;
import com.market.page.CartAddItemPage;
import com.market.page.CartItemListPage;
import com.market.page.CartShippingPage;
import com.market.page.GuestInfoPage;

public class MainWindow extends JFrame {
    private final Cart cart;
    private final Book[] bookList;

    public MainWindow() {
        cart = new Cart();
        bookList = BookInIt.init();

        setTitle("온라인 서점");
        setSize(750, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        setJMenuBar(createMenuBar());

        JLabel title = new JLabel("Welcome to Book Market!", SwingConstants.CENTER);
        add(title, BorderLayout.NORTH);

        JPanel menuPanel = new JPanel(new GridLayout(3, 3, 10, 10));
        JButton[] buttons = new JButton[9];
        buttons[0] = new JButton("1. 고객 정보 확인하기");
        buttons[1] = new JButton("2. 장바구니 상품 목록 보기");
        buttons[2] = new JButton("3. 장바구니 비우기");
        buttons[3] = new JButton("4. 바구니에 항목 추가하기");
        buttons[4] = new JButton("5. 장바구니 항목 수량 줄이기");
        buttons[5] = new JButton("6. 장바구니 항목 삭제하기");
        buttons[6] = new JButton("7. 주문하기");
        buttons[7] = new JButton("8. 종료");
        buttons[8] = new JButton("9. 관리자");

        for (JButton button : buttons) {
            menuPanel.add(button);
        }
        add(menuPanel, BorderLayout.CENTER);

        buttons[0].addActionListener(e -> new GuestInfoPage(UserInIt.getmUser()).setVisible(true));
        buttons[1].addActionListener(e -> new CartItemListPage(cart, false).setVisible(true));
        buttons[2].addActionListener(e -> clearCart());
        buttons[3].addActionListener(e -> new CartAddItemPage(bookList, cart).setVisible(true));
        buttons[4].addActionListener(e -> new CartItemListPage(cart, true).setVisible(true));
        buttons[5].addActionListener(e -> new CartItemListPage(cart, true).setVisible(true));
        buttons[6].addActionListener(e -> orderCart());
        buttons[7].addActionListener(e -> dispose());
        buttons[8].addActionListener(e -> new AdminLoginDialog(this, bookList).setVisible(true));
    }

    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu customerMenu = new JMenu("고객 정보");
        JMenu productMenu = new JMenu("상품 목록");
        JMenu exitMenu = new JMenu("종료");

        JMenuItem customerInfoItem = new JMenuItem("고객 정보 확인하기");
        JMenuItem productListItem = new JMenuItem("장바구니에 항목 추가하기");
        JMenuItem exitItem = new JMenuItem("종료");

        customerInfoItem.addActionListener(e -> new GuestInfoPage(UserInIt.getmUser()).setVisible(true));
        productListItem.addActionListener(e -> new CartAddItemPage(bookList, cart).setVisible(true));
        exitItem.addActionListener(e -> dispose());

        customerMenu.add(customerInfoItem);
        productMenu.add(productListItem);
        exitMenu.add(exitItem);

        menuBar.add(customerMenu);
        menuBar.add(productMenu);
        menuBar.add(exitMenu);
        return menuBar;
    }

    private void clearCart() {
        if (cart.getmCartCount() == 0) {
            JOptionPane.showMessageDialog(this, "장바구니에 항목이 없습니다.");
            return;
        }
        int answer = JOptionPane.showConfirmDialog(this, "장바구니를 비우겠습니까?", "장바구니 비우기", JOptionPane.YES_NO_OPTION);
        if (answer == JOptionPane.YES_OPTION) {
            cart.deleteBook();
            JOptionPane.showMessageDialog(this, "장바구니를 비웠습니다.");
        }
    }

    private void orderCart() {
        if (cart.getmCartCount() == 0) {
            JOptionPane.showMessageDialog(this, "장바구니에 항목이 없습니다.");
            return;
        }
        new CartShippingPage(UserInIt.getmUser(), cart).setVisible(true);
    }
}
