package com.market.main;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

import javax.swing.SwingUtilities;

import com.market.bookitem.Book;
import com.market.cart.Cart;
import com.market.exception.CartException;
import com.market.member.Admin;
import com.market.member.User;
import com.market.member.UserInIt;

public class Welcome {
    static final int NUM_BOOK = 3;
    static final int NUM_ITEM = 7;
    static Cart mCart = new Cart();
    static User mUser;
    static Scanner input = new Scanner(System.in);

    public static void menuIntroduction() {
        System.out.println("***********************************************");
        System.out.println("1. 고객 정보 확인하기 \t4. 바구니에 항목 추가하기");
        System.out.println("2. 장바구니 상품 목록 보기 \t5. 장바구니의 항목 수량 줄이기");
        System.out.println("3. 장바구니 비우기 \t6. 장바구니의 항목 삭제하기");
        System.out.println("7. 영수증 표시하기 \t8. 종료");
        System.out.println("9. 관리자 로그인");
        System.out.println("***********************************************");
    }

    public static void menuGuestInfo() {
        System.out.println("현재 고객 정보 : ");
        System.out.println("이름 " + mUser.getName() + " 연락처 " + mUser.getPhone());
    }

    public static void menuCartItemList() {
        try {
            mCart.printCart();
        } catch (CartException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void menuCartClear() {
        try {
            if (mCart.mCartCount == 0) {
                throw new CartException("장바구니에 항목이 없습니다.");
            }
            System.out.println("장바구니의 모든 항목을 삭제하겠습니까? Y | N");
            String str = input.nextLine();
            if (str.equalsIgnoreCase("Y")) {
                mCart.deleteBook();
                System.out.println("장바구니의 모든 항목을 삭제했습니다.");
            }
        } catch (CartException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void menuCartAddItem(Book[] bookList) {
        mCart.printBookList(bookList);

        boolean quit = false;
        while (!quit) {
            System.out.print("장바구니에 추가할 도서의 ID를 입력하세요 : ");
            String str = input.nextLine();

            boolean flag = false;
            int numId = -1;
            for (int i = 0; i < NUM_BOOK; i++) {
                if (str.equals(bookList[i].getBookId())) {
                    numId = i;
                    flag = true;
                    break;
                }
            }

            if (flag) {
                System.out.println("장바구니에 추가하겠습니까? Y | N");
                str = input.nextLine();
                if (str.equalsIgnoreCase("Y")) {
                    System.out.println(bookList[numId].getBookId() + " 도서가 장바구니에 추가되었습니다.");
                    if (!mCart.isCartInBook(bookList[numId].getBookId())) {
                        mCart.insertBook(bookList[numId]);
                    }
                }
                quit = true;
            } else {
                System.out.println("다시 입력해 주세요.");
            }
        }
    }

    public static void menuCartRemoveItemCount() {
        try {
            if (mCart.mCartCount == 0) {
                throw new CartException("장바구니에 항목이 없습니다.");
            }
            menuCartItemList();
            System.out.print("수량을 줄일 도서 ID를 입력하세요 : ");
            String bookId = input.nextLine();

            for (int i = 0; i < mCart.mCartCount; i++) {
                if (bookId.equals(mCart.mCartItem[i].getBookId())) {
                    int quantity = mCart.mCartItem[i].getQuantity();
                    if (quantity > 1) {
                        mCart.mCartItem[i].setQuantity(quantity - 1);
                        System.out.println("수량을 1 줄였습니다.");
                    } else {
                        mCart.removeCart(i);
                        System.out.println("수량이 1개였기 때문에 항목을 삭제했습니다.");
                    }
                    return;
                }
            }
            System.out.println("해당 도서 ID가 장바구니에 없습니다.");
        } catch (CartException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void menuCartRemoveItem() {
        try {
            if (mCart.mCartCount == 0) {
                throw new CartException("장바구니에 항목이 없습니다.");
            }
            menuCartItemList();
            boolean quit = false;
            while (!quit) {
                System.out.print("장바구니에서 삭제할 도서의 ID를 입력하세요 : ");
                String str = input.nextLine();

                boolean flag = false;
                int numId = -1;
                for (int i = 0; i < mCart.mCartCount; i++) {
                    if (str.equals(mCart.mCartItem[i].getBookId())) {
                        numId = i;
                        flag = true;
                        break;
                    }
                }

                if (flag) {
                    System.out.println("장바구니의 항목을 삭제하겠습니까? Y | N");
                    str = input.nextLine();
                    if (str.equalsIgnoreCase("Y")) {
                        System.out.println(mCart.mCartItem[numId].getBookId() + " 장바구니에서 도서가 삭제되었습니다.");
                        mCart.removeCart(numId);
                    }
                    quit = true;
                } else {
                    System.out.println("다시 입력해 주세요.");
                }
            }
        } catch (CartException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void menuCartBill() {
        try {
            if (mCart.mCartCount == 0) {
                throw new CartException("장바구니에 항목이 없습니다.");
            }
            System.out.println("배송받을 분은 고객 정보와 같습니까? Y | N");
            String str = input.nextLine();

            String name = mUser.getName();
            int phone = mUser.getPhone();
            String address;

            if (str.equalsIgnoreCase("Y")) {
                System.out.print("배송지를 입력하세요 : ");
                address = input.nextLine();
            } else {
                System.out.print("배송받을 고객명을 입력하세요 : ");
                name = input.nextLine();
                System.out.print("배송받을 고객의 연락처를 입력하세요 : ");
                phone = input.nextInt();
                input.nextLine();
                System.out.print("배송받을 고객의 배송지를 입력하세요 : ");
                address = input.nextLine();
            }
            printBill(name, phone, address);
        } catch (CartException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void printBill(String name, int phone, String address) {
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
        String strDate = formatter.format(date);

        System.out.println();
        System.out.println("--------------- 배송 받을 고객 정보 ---------------");
        System.out.println("고객명 : " + name + "\t연락처 : " + phone);
        System.out.println("배송지 : " + address + "\t발송일 : " + strDate);
        System.out.println("장바구니 상품 목록 :");
        System.out.println("------------------------------------------------");
        System.out.println("도서ID \t\t 수량 \t 합계");
        for (int i = 0; i < mCart.mCartCount; i++) {
            System.out.print(mCart.mCartItem[i].getBookId() + " \t ");
            System.out.print(mCart.mCartItem[i].getQuantity() + " \t ");
            System.out.println(mCart.mCartItem[i].getTotalPrice());
        }
        System.out.println("------------------------------------------------");
        System.out.println("주문 총금액 : " + mCart.getTotalPrice() + "원");
    }

    public static void menuExit() {
        System.out.println("8. 종료");
    }

    public static void menuAdminLogin() {
        Admin admin = new Admin("관리자", 123456789);

        System.out.println("관리자 정보를 입력하세요.");
        System.out.print("아이디 : ");
        String adminId = input.nextLine();
        System.out.print("비밀번호 : ");
        String adminPw = input.nextLine();

        if (adminId.equals(admin.getId()) && adminPw.equals(admin.getPassword())) {
            System.out.println("관리자 이름 : " + admin.getName() + "\t연락처 : " + admin.getPhone());
            System.out.println("아이디 : " + admin.getId() + "\t비밀번호 : " + admin.getPassword());
        } else {
            System.out.println("관리자 정보가 일치하지 않습니다.");
        }
    }

    public static void BookList(Book[] bookList) {
        bookList[0] = new Book("ISBN1234", "쉽게 배우는 JSP 웹 프로그래밍", 27000);
        bookList[0].setAuthor("송미영");
        bookList[0].setDescription("단계별로 쇼핑몰을 구현하며 배우는 JSP 웹 프로그래밍");
        bookList[0].setCategory("IT전문서");
        bookList[0].setReleaseDate("2018/10/08");

        bookList[1] = new Book("ISBN1235", "안드로이드 프로그래밍", 33000);
        bookList[1].setAuthor("우재남");
        bookList[1].setDescription("실습 단계별 명쾌한 멘토링!");
        bookList[1].setCategory("IT전문서");
        bookList[1].setReleaseDate("2022/01/22");

        bookList[2] = new Book("ISBN1236", "스크래치", 22000);
        bookList[2].setAuthor("고광일");
        bookList[2].setDescription("컴퓨팅 사고력을 키우는 블록 코딩");
        bookList[2].setCategory("컴퓨터입문");
        bookList[2].setReleaseDate("2019/06/10");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GuestWindow().setVisible(true));
    }
}
