package com.market.page;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import com.market.bookitem.Book;
import com.market.member.Admin;

public class AdminLoginDialog extends JDialog {
    private final JTextField idField;
    private final JPasswordField passwordField;
    private final Book[] bookList;

    public AdminLoginDialog(JFrame owner, Book[] bookList) {
        super(owner, "관리자 로그인", true);
        this.bookList = bookList;

        setSize(360, 220);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(10, 10));

        JPanel inputPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        inputPanel.add(new JLabel("아이디"));
        idField = new JTextField();
        inputPanel.add(idField);
        inputPanel.add(new JLabel("비밀번호"));
        passwordField = new JPasswordField();
        inputPanel.add(passwordField);
        add(inputPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton loginButton = new JButton("추가");
        JButton cancelButton = new JButton("취소");
        buttonPanel.add(loginButton);
        buttonPanel.add(cancelButton);
        add(buttonPanel, BorderLayout.SOUTH);

        loginButton.addActionListener(e -> login());
        cancelButton.addActionListener(e -> dispose());
    }

    private void login() {
        Admin admin = new Admin("관리자", 123456789);
        String id = idField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (id.equals(admin.getId()) && password.equals(admin.getPassword())) {
            new AdminPage(bookList).setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "관리자 정보가 일치하지 않습니다.");
        }
    }
}
