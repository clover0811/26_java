package com.market.page;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import com.market.bookitem.Book;

public class AdminPage extends JFrame {
    private final JLabel selectedBookLabel;
    private final JTable table;

    public AdminPage(Book[] bookList) {
        setTitle("관리자");
        setSize(800, 420);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        selectedBookLabel = new JLabel("도서 목록 테이블에서 행을 선택하세요.", SwingConstants.CENTER);
        add(selectedBookLabel, BorderLayout.NORTH);

        String[] columnNames = {"도서ID", "도서명", "가격", "저자", "분야", "출간일"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        for (Book book : bookList) {
            model.addRow(new Object[] {
                    book.getBookId(),
                    book.getName(),
                    book.getUnitPrice(),
                    book.getAuthor(),
                    book.getCategory(),
                    book.getReleaseDate()
            });
        }

        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton addButton = new JButton("추가");
        JButton cancelButton = new JButton("취소");
        buttonPanel.add(addButton);
        buttonPanel.add(cancelButton);
        add(buttonPanel, BorderLayout.SOUTH);

        table.getSelectionModel().addListSelectionListener(e -> showSelectedBook(bookList));
        addButton.addActionListener(e -> showSelectedBook(bookList));
        cancelButton.addActionListener(e -> dispose());
    }

    private void showSelectedBook(Book[] bookList) {
        int row = table.getSelectedRow();
        if (row >= 0) {
            selectedBookLabel.setText(bookList[row].getBookId() + " / " + bookList[row].getName());
        }
    }
}
