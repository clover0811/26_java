package com.market.page;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import com.market.bookitem.Book;
import com.market.cart.Cart;

public class CartAddItemPage extends JFrame {
    private final Book[] bookList;
    private final Cart cart;
    private final JTable table;
    private final JLabel selectedBookLabel;

    public CartAddItemPage(Book[] bookList, Cart cart) {
        this.bookList = bookList;
        this.cart = cart;

        setTitle("장바구니에 항목 추가하기");
        setSize(850, 420);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        String[] columnNames = {"도서ID", "도서명", "가격", "저자", "분야", "출간일"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        for (Book book : bookList) {
            model.addRow(new Object[] {
                    book.getBookId(),
                    book.getName(),
                    book.getUnitPrice(),
                    book.getAuthor(),
                    book.getCategory(),
                    book.getReleaseDate()
            });
        }

        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        selectedBookLabel = new JLabel("도서 목록 테이블에서 행을 선택하세요.", SwingConstants.CENTER);
        add(selectedBookLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton addButton = new JButton("장바구니에 담기");
        JButton closeButton = new JButton("닫기");
        buttonPanel.add(addButton);
        buttonPanel.add(closeButton);
        add(buttonPanel, BorderLayout.SOUTH);

        table.getSelectionModel().addListSelectionListener(e -> showSelectedBook());
        addButton.addActionListener(e -> addSelectedBook());
        closeButton.addActionListener(e -> dispose());
    }

    private void showSelectedBook() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            selectedBookLabel.setText(bookList[row].getBookId() + " / " + bookList[row].getName());
        }
    }

    private void addSelectedBook() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "장바구니에 담을 도서를 선택하세요.");
            return;
        }

        Book selectedBook = bookList[row];
        if (!cart.isCartInBook(selectedBook.getBookId())) {
            cart.insertBook(selectedBook);
        }
        JOptionPane.showMessageDialog(this, selectedBook.getBookId() + " 도서가 장바구니에 추가되었습니다.");
    }
}
