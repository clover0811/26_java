package com.market.page;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.market.cart.Cart;
import com.market.cart.CartItem;

public class CartItemListPage extends JFrame {
    private final Cart cart;
    private final JTable table;
    private final DefaultTableModel model;

    public CartItemListPage(Cart cart, boolean allowEdit) {
        this.cart = cart;

        setTitle("장바구니 상품 목록 보기");
        setSize(650, 380);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        String[] columnNames = {"도서ID", "도서명", "수량", "합계"};
        model = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(model);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton refreshButton = new JButton("장바구니 새로 고침");
        JButton decreaseButton = new JButton("수량 줄이기");
        JButton removeButton = new JButton("장바구니의 항목 삭제하기");
        JButton clearButton = new JButton("장바구니 비우기");
        JButton closeButton = new JButton("닫기");

        buttonPanel.add(refreshButton);
        if (allowEdit) {
            buttonPanel.add(decreaseButton);
            buttonPanel.add(removeButton);
        }
        buttonPanel.add(clearButton);
        buttonPanel.add(closeButton);
        add(buttonPanel, BorderLayout.SOUTH);

        refreshButton.addActionListener(e -> refreshTable());
        decreaseButton.addActionListener(e -> decreaseSelectedItem());
        removeButton.addActionListener(e -> removeSelectedItem());
        clearButton.addActionListener(e -> clearCart());
        closeButton.addActionListener(e -> dispose());

        refreshTable();
    }

    private void refreshTable() {
        model.setRowCount(0);
        CartItem[] items = cart.getmCartItem();
        for (int i = 0; i < cart.getmCartCount(); i++) {
            model.addRow(new Object[] {
                    items[i].getBookId(),
                    items[i].getItemBook().getName(),
                    items[i].getQuantity(),
                    items[i].getTotalPrice()
            });
        }
    }

    private void decreaseSelectedItem() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "수량을 줄일 항목을 선택하세요.");
            return;
        }
        CartItem item = cart.getmCartItem()[row];
        if (item.getQuantity() > 1) {
            item.setQuantity(item.getQuantity() - 1);
        } else {
            cart.removeCart(row);
        }
        refreshTable();
    }

    private void removeSelectedItem() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "삭제할 항목을 선택하세요.");
            return;
        }
        cart.removeCart(row);
        refreshTable();
    }

    private void clearCart() {
        if (cart.getmCartCount() == 0) {
            JOptionPane.showMessageDialog(this, "장바구니에 항목이 없습니다.");
            return;
        }
        cart.deleteBook();
        refreshTable();
    }
}
