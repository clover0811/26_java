package com.market.page;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import com.market.cart.Cart;
import com.market.cart.CartItem;

public class CartOrderBillPage extends JFrame {
    public CartOrderBillPage(String name, String phone, String address, Cart cart) {
        setTitle("주문 영수증 표시하기");
        setSize(680, 420);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        String date = new SimpleDateFormat("MM/dd/yyyy").format(new Date());

        JPanel infoPanel = new JPanel(new GridLayout(4, 2, 10, 5));
        infoPanel.add(new JLabel("고객명"));
        infoPanel.add(new JLabel(name));
        infoPanel.add(new JLabel("연락처"));
        infoPanel.add(new JLabel(phone));
        infoPanel.add(new JLabel("배송지"));
        infoPanel.add(new JLabel(address));
        infoPanel.add(new JLabel("발송일"));
        infoPanel.add(new JLabel(date));
        add(infoPanel, BorderLayout.NORTH);

        String[] columnNames = {"도서ID", "도서명", "수량", "합계"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        CartItem[] items = cart.getmCartItem();
        for (int i = 0; i < cart.getmCartCount(); i++) {
            model.addRow(new Object[] {
                    items[i].getBookId(),
                    items[i].getItemBook().getName(),
                    items[i].getQuantity(),
                    items[i].getTotalPrice()
            });
        }

        add(new JScrollPane(new JTable(model)), BorderLayout.CENTER);
        add(new JLabel("주문 총금액 : " + cart.getTotalPrice() + "원", SwingConstants.RIGHT), BorderLayout.SOUTH);
    }
}
