package com.market.page;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import com.market.cart.Cart;
import com.market.member.User;

public class CartShippingPage extends JFrame {
    private final User user;
    private final Cart cart;
    private final JTextField nameField;
    private final JTextField phoneField;
    private final JTextField addressField;
    private final JRadioButton yesButton;
    private final JRadioButton noButton;

    public CartShippingPage(User user, Cart cart) {
        this.user = user;
        this.cart = cart;

        setTitle("주문 배송지 입력");
        setSize(460, 300);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel radioPanel = new JPanel(new FlowLayout());
        radioPanel.add(new JLabel("배송받을 분은 고객 정보와 같습니까?"));
        yesButton = new JRadioButton("예");
        noButton = new JRadioButton("아니요");
        ButtonGroup group = new ButtonGroup();
        group.add(yesButton);
        group.add(noButton);
        radioPanel.add(yesButton);
        radioPanel.add(noButton);
        add(radioPanel, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        inputPanel.add(new JLabel("고객명"));
        nameField = new JTextField();
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("연락처"));
        phoneField = new JTextField();
        inputPanel.add(phoneField);
        inputPanel.add(new JLabel("배송지"));
        addressField = new JTextField();
        inputPanel.add(addressField);
        add(inputPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton orderButton = new JButton("주문 완료");
        JButton cancelButton = new JButton("취소");
        buttonPanel.add(orderButton);
        buttonPanel.add(cancelButton);
        add(buttonPanel, BorderLayout.SOUTH);

        yesButton.addActionListener(e -> fillUserInfo());
        noButton.addActionListener(e -> clearFields());
        orderButton.addActionListener(e -> orderComplete());
        cancelButton.addActionListener(e -> dispose());
    }

    private void fillUserInfo() {
        nameField.setText(user.getName());
        phoneField.setText(String.valueOf(user.getPhone()));
        addressField.requestFocus();
    }

    private void clearFields() {
        nameField.setText("");
        phoneField.setText("");
        addressField.setText("");
        nameField.requestFocus();
    }

    private void orderComplete() {
        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        String address = addressField.getText().trim();

        if (name.isEmpty() || phone.isEmpty() || address.isEmpty()) {
            JOptionPane.showMessageDialog(this, "고객명, 연락처, 배송지를 모두 입력하세요.");
            return;
        }

        new CartOrderBillPage(name, phone, address, cart).setVisible(true);
        dispose();
    }
}
