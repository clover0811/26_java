package com.market.page;

import java.awt.BorderLayout;
import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import com.market.member.User;

public class GuestInfoPage extends JFrame {
    public GuestInfoPage(User user) {
        setTitle("고객 정보 확인하기");
        setSize(360, 220);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel("고객 정보", SwingConstants.CENTER);
        add(title, BorderLayout.NORTH);

        JPanel panel = new JPanel(new GridLayout(2, 2, 10, 10));
        panel.add(new JLabel("이름"));
        panel.add(new JLabel(user.getName()));
        panel.add(new JLabel("연락처"));
        panel.add(new JLabel(String.valueOf(user.getPhone())));
        add(panel, BorderLayout.CENTER);
    }
}
