package Bookmarket;

public class Person {

	String name;
	int phone;
	
	public Person(String name, int phone) {
	
		this.name = name;
		this.phone = phone;
	}
	
	
	public static void main(String[] args) {
		
	}

}