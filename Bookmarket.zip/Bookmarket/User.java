package Bookmarket;

public class User extends Person {
	
	String addr;
	
	public User(String name, int phone, String addr) {
		super(name, phone);
		this.addr = addr;
	}
	
	public static void main(String[] args) {
		
	}

}