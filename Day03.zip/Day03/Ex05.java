package Day03;
import java.util.Scanner;

public class Ex05 {

	public static void main(String[] args) {
		
		Scanner n = new Scanner(System.in);
		System.out.println("점수를 입력하세요: ");
		int num = n.nextInt();
		//짝수이면 짝수입니다. 아니면 홀수입니다.
		
		
		if(num >= 70)
			System.out.println("합격입니다."); // 참일 때 실행문
		else
			System.out.println("불합격입니다."); // 거짓일 때 실행문
		

	}

}
