package Day03;
import java.util.Scanner;

public class Ex06 {

	public static void main(String[] args) {
		
		Scanner n = new Scanner(System.in);
		// id, pwd 초기화
		String id = "java", pwd = "programming";
				
		System.out.println("아이디를 입력하세요: ");
		String myid = n.next();
		
		System.out.println("패스워드를 입력하세요: ");
		String mypwd = n.next();
		
				
		if((myid.equals(id)) && (mypwd.equals(pwd)))
			System.out.println("로그인 성공"); // 참일 때 실행문
		else
			System.out.println("로그인 실패"); // 거짓일 때 실행문
		

	}

}
