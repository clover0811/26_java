package day07;

import java.util.Scanner;

public class BookArray {

	public static void main(String[] args) {
		Book books [] = new Book[2];
		
		Scanner s = new Scanner(System.in);
		for(int i = 0; i<books.length; i++) {
			System.out.print("제목을 입력하세요 : ");
			String title = s.nextLine();
			System.out.print("저자를 입력하세요 : ");
			String author = s.nextLine();
			books[i] = new Book(title, author);
		}
		
		for(int i = 0; i<books.length; i++) {
			System.out.print("(" + books[i].title + "," + books[i].author + ")");
		}
		
	}

}
