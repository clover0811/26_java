package day07;

public class PersonTest {

	public static void main(String[] args) {
		// Person 객체 생성하기
		Person hong = new Person(); // 디폴트 생성자
//		hong.name = "홍길동";
//		hong.age = 20;
//		hong.abc = 'A';
		hong.밥먹기();
		hong.운동하기("헬스");
		
		// hong.addr = "대전동구 용운동";
		
		System.out.println(Person.getName()); // static 메소드호출은 클래스이름.으로 사용가능
		
		
		

	}

}
