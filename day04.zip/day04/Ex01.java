package day04;

import java.util.Scanner;
public class Ex01 {

	public static void main(String[] args) {
		
		
		
		Scanner a = new Scanner(System.in);
		System.out.println("나이를 입력하세요 : ");
		int age = a.nextInt();
		
		if(age < 18)
			System.out.println("청소년 관람 불가");
		

	}

}
