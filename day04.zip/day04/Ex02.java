package day04;

import java.util.Scanner;
public class Ex02 {

	public static void main(String[] args) {
		
		
		Scanner s = new Scanner(System.in);
		System.out.println("필기시험 점수를 입력하세요 : ");
		int score1 = s.nextInt();
		
		System.out.println("토익 점수를 입력하세요 : ");
		int score2 = s.nextInt();
		
		if((score1 >= 80) && (score2 >= 850))
			System.out.println("합격");
		else
			System.out.println("불합격");
		

	}

}
