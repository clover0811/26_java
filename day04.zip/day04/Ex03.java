package day04;

import java.util.Scanner;
public class Ex03 {

	public static void main(String[] args) {
		
		
		Scanner s = new Scanner(System.in);
		int balance = 10000;
		System.out.println("나이를 입력하시오 : ");
		int age = s.nextInt();
		
		if((age > 6) && (age < 13)) {
			balance = balance - 450;
			System.out.println("잔액이" + balance + "원 남았습니다.");
		}
		else if((age > 12) && (age < 19)) {
			balance = balance - 720;
			System.out.println("잔액이" + balance + "원 남았습니다.");
		}
		else if((age > 18)) {
			balance = balance - 1200;
			System.out.println("잔액이" + balance + "원 남았습니다.");
		}
		
		s.close();
		

	}

}
