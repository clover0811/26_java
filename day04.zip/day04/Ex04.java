package day04;
/*
 * 철수와 영희 두 사람이 가위바위보 게임을 한다.
 * 먼저 철수>>>를 출력하고 가위, 바위, 보 중 하나를 문자열로 입력받는다.
 * 그리고 영희>>>를 출력하고 마찬가지로 입력 하나를 문자열로 받는다.
 * 입력받은 문자열을 비교하여 누가 이겼는지 판단하여 승자를 출력한다.
 * 
 * ---출력 결과---
 * 가위, 바위, 보 게임입니다. 가위, 바위, 보 중에서 입력하세요
 * 철수 >>> 가위
 * 영희 >>> 보
 * 철수가 이겼습니다.
 */

import java.util.Scanner;
public class Ex04 {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		System.out.println("가위, 바위, 보 게임입니다. 가위, 바위, 보 중에서 입력하세요 : ");
		String user1 = s.next();
		System.out.println("철수 >>>" + user1);
		System.out.println("가위, 바위, 보 중에서 입력하세요 : ");
		String user2 = s.next();
		System.out.println("영희 >>>" + user2);
		
		//철수가 승리할 모든 경우
		if((user1.equals("보"))){
			if(user2.equals("보")) {
				System.out.println("비겼습니다.");
			}
			else if(user2.equals("바위")) {
				System.out.println("철수가 이겼습니다.");
			}
			else {
				System.out.println("철수가 졌습니다.");
			}
		}
		else if((user1.equals("바위"))) {
			if(user2.equals("바위")) {
				System.out.println("비겼습니다.");
			}
			else if(user2.equals("가위")) {
				System.out.println("철수가 이겼습니다.");
			}
			else {
				System.out.println("철수가 졌습니다.");
			}
		}
		else if((user1.equals("가위"))) {
			if(user2.equals("가위")) {
				System.out.println("비겼습니다.");
			}
			else if(user2.equals("보")) {
				System.out.println("철수가 이겼습니다.");
			}
			else {
				System.out.println("철수가 졌습니다.");
			}
		}

	}

}
