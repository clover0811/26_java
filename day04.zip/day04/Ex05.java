package day04;

import java.util.Scanner;
public class Ex05 {

	public static void main(String[] args) {
		
		// 1부터 10까지의 합을 계산하는 for 반복문 완성
		int sum = 0;
		for(int i = 1; i <=10; i++) {
			sum = sum + i;
			//System.out.println(i);
			
		}
		System.out.println(sum);

	}

}
