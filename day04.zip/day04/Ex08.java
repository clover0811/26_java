package day04;

import java.util.Scanner;
public class Ex08 {

	// 5개의 정수 입력 받아서 양수의 합 구하기
	
	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		int sum = 0;
		System.out.println("정수를 입력하세요.");
		
		for(int i = 1; i<=5; i++) {
			int num = s.nextInt();
			// 만약 정수가 음수라면 무시, 양수이면 합 추가
			if(num <= 0) {
				continue;
			}
			else {
				sum = sum + num;
			}
		}
		System.out.println("양수의 합은 " + sum + "입니다");
		
		s.close();

	}

}
