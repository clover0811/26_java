package day04;

import java.util.Scanner;
public class Ex09 {

	// 무한반복해서 정수를 입력한 후, 음수가 입력되면 무한반복을 종료
	// 누적의 합을 출력
	
	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		int sum = 0;
		System.out.println("정수를 입력하세요.");
		
		while(true) {
			int num = s.nextInt();
			if(num <= 0) {
				break;
			}
			else {
				sum = sum + num;
			}
		}
		System.out.println("합은" + sum);

		
		
	}

}
