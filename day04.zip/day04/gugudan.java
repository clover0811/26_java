package day04;

public class gugudan {

	public static void main(String[] args) {
		
		//2단 중첩 for문 활용하기
		//2단부터 9단까지..for문
		//안쪽 *1, *2, *3...*9 .. for문
		
		for(int i=2; i<10; i++) { // 2단에서 9단까지
			for(int j=1; j<10; j++) {
				System.out.print(i + "*" + j + "=" + i*j);
				System.out.print('\t');
			}
			
			System.out.println();
		}

	}

}
