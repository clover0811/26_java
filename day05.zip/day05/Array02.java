package day05;
import java.util.Scanner;

public class Array02 {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		
		// 1차원 배열 선언
		int intArray [];
		// 배열 생성
		intArray = new int[5];
		int sum = 0; 
		double average;
		
		System.out.println("5개 양수 입력하기");
		for (int i=0; i<intArray.length; i++) {
			intArray[i] = s.nextInt();
				sum = sum + intArray[i];
		}
		average = sum / intArray.length;
		
		System.out.println("평균은 " + average + "입니다.");
		
		
		

	}

}