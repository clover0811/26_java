package day05;

public class Array05 {

	public static void main(String[] args) {
		
		// 2차원 배열... 4행 2열
		double score[][] = {{4.0, 3.5}, {4.5, 4.2}, {4.2, 4.3}, {4.5, 4.5}};
		
		// 평균 평점 구하기
		double sum = 0;
		
		
		try {
			for(int i=0; i<score.length; i++) {
				for(int j=0; j<score[i].length; j++) {
					sum += score[i][j];
				}
			}
		// i가 4보다 크면 catch
		} catch(ArrayIndexOutOfBoundsException a) {
			a.printStackTrace();
		}
		int n = score.length;
		int m = score[0].length;
		
		System.out.println("4년 전체 평점 평균은 " + sum/(n*m) + "입니다.");

	}

}
