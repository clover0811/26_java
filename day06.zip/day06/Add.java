package day06;

import java.util.Scanner;
public class Add {

	public static void main(String[] args) {
		// 2개의 실수를 입력 받아서 더한 결과를 출력하시오.
		
		double num1, num2, num3;

		Scanner s = new Scanner(System.in);
		System.out.println("첫번째 실수를 입력하세요 : ");
		num1 = s.nextDouble();
		System.out.println("두번째 실수를 입력하세요 : ");
		num2 = s.nextDouble();
		
		num3 = num1 * num2;
		System.out.println("두 실수의 곱: " + num3);

		
		
		
		
		
		
	}

}
