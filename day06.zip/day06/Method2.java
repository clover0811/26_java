package day06;

import java.util.Scanner;

public class Method2 {
	// 2개의 정수를 입력 받아서 최대값을 반환하는 max()메소드를 정의하고 호출 한 후 결과를 출력하시오.
	
	public static int max(int a, int b) {
		int result;
		if(a > b) {
			result = a;
		}
		else {
			result = b;
		}
		return result;
	}
	
	
	public static void main(String[] args) {
		System.out.println(max(20, 30));
	
	}

}