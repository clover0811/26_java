package day06;

import java.util.Scanner;
public class Method3 {
	
	// 2개의 정수와 1개의 문자열을 입력 받아서 사칙연산을 수행하는 계산기 메소드 add(), sub(), mul(), div()를 정의하시오.
	// 문자열이 + 이면 add() 호출, - 이면 sub() 호출, * 이면 mul() 호출, / 이면 div() 호출

	public static int add(int a, int b, String n) {
		
		return a + b;
	}
	
	public static int sub(int a, int b, String n) {
		
		return a - b;
	}
	
	public static int mul(int a, int b, String n) {
		
		return a * b;
	}
	
	public static int div(int a, int b, String n) {
		
		return a / b;
	}
	
	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		
		int a, b;
		String n;
		
		System.out.println("정수 1 입력 : ");
		a = s.nextInt();
		System.out.println("정수 2 입력 : ");
		b = s.nextInt();
		System.out.println("연산 부호를 입력 : ");
		n = s.next();
		
		switch(n) {
		case "+":
			System.out.println(a + "+" + b + "=" + add(a,b,n));
			break;
		case "-":
			System.out.println(a + "-" + b + "=" + sub(a,b,n));
			break;
		case "*":
			System.out.println(a + "*" + b + "=" + mul(a,b,n));
			break;
		case "/":
			System.out.println(a + "/" + b + "=" + div(a,b,n));
			break;
		default:
			break;
		}

	}

}
