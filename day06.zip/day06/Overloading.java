package day06;

public class Overloading {
	// 메소드 오버로딩 : 메소드 이름은 같고, 매개변수의 개수와 타입은 다르게 정의하는 것
	
	public static void coffee(int c) { // 블랙커피
		System.out.println("블랙 커피 만듭니다.");
	}
	
	public static void coffee(int c, int cr) { // 크림커피
		System.out.println("크림 커피 만듭니다.");
	}
	
	public static void coffee(int c, int cr, int s) { // 믹스커피
		System.out.println("믹스 커피 만듭니다.");
	}
	
	
	public static void main(String[] args) {
		coffee(3,3,3);
		coffee(2);
		coffee(3,2);
		

	}

}
