package day09;

public class Student extends Human{

	private String sid;
	
	public Student(String name, int age, String sid) {
		super(name,age);
		this.sid = sid;
	}
	
	// getter, setter
	
	
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	
	public static void main(String[] args) {

	}

}
