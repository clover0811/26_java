package day10;
import java.util.*;
abstract class Player { // 추상 클래스
    public String shape[] = {"가위", "바위", "보"};
    private String name;
    public Player(String name) {
        this.name = name;
    }
    public String getName() {
        return name;
    }

    abstract public String turn(); //선수가 가위바위보 중 하나를 리턴
}

class MachinePlayer extends Player {

    public MachinePlayer(String name) {
        super(name);
    }
    
    @Override
    public String turn() {
    	// 난수 생성 객체
        Random random = new Random();
        	 int num = random.nextInt(3); // 임의의 정수 : 0, 1, 2 생성
             	return shape[num];
       
    }
}

class HumanPlayer extends Player {
    private Scanner scanner = new Scanner(System.in);

    public HumanPlayer(String name) {
        super(name);
    }

    public String turn() {
        System.out.print(getName() + "님, 뭘 내시겠습니까? ");
        return scanner.next();
    }
}

public class App {
    public static void main(String[] args) {
        Player machine = new MachinePlayer("터미네이터");
        Player human = new HumanPlayer("황기태");

        String m = machine.turn();
        String h = human.turn();

        System.out.println(machine.getName() + ":" + m + ", " + human.getName() + ":" + h);

        if (h.equals(m)) {
            System.out.println(machine.getName() + " 승리!");
        } else {
            System.out.println(human.getName() + " 승리!");
        }
    }
}
