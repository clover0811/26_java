package day10;

public class Researcher extends Person{
	
	public Researcher(String name, String id) {
		super(name, id);
	}
}
