public class DataTypeTest {

	public static void main(String[] args) {
		// 1. 기본형
		boolean isTrue;
		int age;
		double height, weight;
		
		// 2. 변수 초기화
		isTrue = false;
		age = 23;
		height = 180;
		weight = 74;
		
		// 3. 래퍼런스형 - 3개 (array, class, interface)
		String name = "minyoung";
		// name = "minyoung";
		String s = new String("미녕");
		
		
		DataTypeTest dtt = new DataTypeTest();
		// 주소 addr
		String addr = "경기도 이천";
		
		
		// 4. 변수 값 출력하기
		System.out.println(isTrue);
		System.out.println("나이 : "+age);
		System.out.println("키 : "+height);
		System.out.println("몸무게 : "+weight);
		System.out.println("이름 : "+name);
		System.out.println("주소 : "+addr);
		

	}

}
