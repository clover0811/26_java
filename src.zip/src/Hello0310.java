public class Hello0310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// print계열 메소드를 이용해 자바로 하고싶은 것 작성해서 출력 하기
		System.out.println("제가 자바로 하고싶은 것은");
		System.out.println("수업 내용이라도 잘 이해하기 입니다\n파이팅><");
		
	}

}
